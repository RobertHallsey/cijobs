<!DOCTYPE html>
<html>
<head>
	<title>Job Board Scraper</title>
	<base href='<?php echo base_url(); ?>' />
	<link rel="stylesheet" type="text/css" href="assets/style.css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>

<div id="page">

	<div id="header"><h1>Job Board Scraper</h1></div>

